package com.example.demoship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoShipApplicationTests {

    @Test
    void contextLoads() {
    }

}
